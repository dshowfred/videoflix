<!-- BEGIN CORE JS FRAMEWORK-->
<script src="<?php echo site_url('assets/backend/plugins/pace/pace.min.js');?>" type="text/javascript"></script>
<!-- BEGIN JS DEPENDECENCIES-->
<script src="<?php echo site_url('assets/backend/plugins/jquery/jquery-1.11.3.min.js');?>" type="text/javascript"></script>
<script src="<?php echo site_url('assets/backend/plugins/bootstrapv3/js/bootstrap.min.js');?>" type="text/javascript"></script>
<script src="<?php echo site_url('assets/backend/plugins/jquery-block-ui/jqueryblockui.min.js');?>" type="text/javascript"></script>
<script src="<?php echo site_url('assets/backend/plugins/jquery-unveil/jquery.unveil.min.js');?>" type="text/javascript"></script>
<script src="<?php echo site_url('assets/backend/plugins/jquery-scrollbar/jquery.scrollbar.min.js');?>" type="text/javascript"></script>
<script src="<?php echo site_url('assets/backend/plugins/jquery-numberAnimate/jquery.animateNumbers.js');?>" type="text/javascript"></script>
<script src="<?php echo site_url('assets/backend/plugins/jquery-validation/js/jquery.validate.min.js');?>" type="text/javascript"></script>
<script src="<?php echo site_url('assets/backend/plugins/bootstrap-select2/select2.min.js');?>" type="text/javascript"></script>
<!-- END CORE JS DEPENDECENCIES-->
<!-- BEGIN CORE TEMPLATE JS -->
<script src="<?php echo site_url('assets/backend/webarch/js/webarch.js');?>" type="text/javascript"></script>
<script src="<?php echo site_url('assets/backend/js/chat.js');?>" type="text/javascript"></script>
<!-- END CORE TEMPLATE JS -->

<!-- DATA TABLE PLUGINS -->
<script src="<?php echo site_url('assets/backend/plugins/jquery-datatable/js/jquery.dataTables.min.js');?>" type="text/javascript"></script>
<script src="<?php echo site_url('assets/backend/plugins/jquery-datatable/extra/js/dataTables.tableTools.min.js');?>" type="text/javascript"></script>
<script src="<?php echo site_url('assets/backend/plugins/datatables-responsive/js/datatables.responsive.js');?>"></script>
<script src="<?php echo site_url('assets/backend/plugins/datatables-responsive/js/lodash.min.js');?>"></script>

<script src="<?php echo site_url('assets/backend/js/datatables.js');?>" type="text/javascript"></script>




<!-- custom js -->
<script src="<?php echo site_url('assets/backend/js/custom.js');?>"></script>